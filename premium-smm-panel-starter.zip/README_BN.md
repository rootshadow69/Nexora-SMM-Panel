# Premium SMM Panel Starter (বাংলা)

এটি একটি MVP starter: Express API + PostgreSQL + Telegram Bot + Mini App frontend।
এখনই বাস্তব পেমেন্ট বা তৃতীয় পক্ষের SMM provider চালু করার মতো সম্পূর্ণ production system নয়।

## গুরুত্বপূর্ণ ব্যবহারবিধি
- শুধু অনুমোদিত, আইনসম্মত এবং সংশ্লিষ্ট সোশ্যাল প্ল্যাটফর্মের শর্ত মেনে চলে—এমন সার্ভিস তালিকাভুক্ত করুন।
- গ্রাহকের Facebook/Instagram/TikTok পাসওয়ার্ড বা লগইন কোড কখনও চাইবেন না।
- Provider API key কখনও browser/Mini App-এ রাখবেন না।
- Payment webhook-এ provider-এর official signature verification না বসানো পর্যন্ত payment credit করবেন না।
- `/api/setup/admin` দিয়ে প্রথম admin তৈরির পর route-টি সরিয়ে দিন বা বন্ধ করুন।
- Production-এ rate limiting, CSRF/CORS policy, audit logs, monitoring, backups, HTTPS এবং proper Telegram Mini App `initData` server-side validation যোগ করুন।

## 1. দরকারি জিনিস
- Node.js 20+
- PostgreSQL database
- Telegram bot token (BotFather থেকে)
- Hosting: Node.js backend host + static frontend (একই Express app-এ `public/` পরিবেশন করা হচ্ছে)

## 2. চালু করুন
```bash
npm install
cp .env.example .env
```
`.env`-এ `DATABASE_URL`, অন্তত 32 অক্ষরের random `JWT_SECRET`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` বসান।

PostgreSQL-এ schema চালান:
```bash
psql "$DATABASE_URL" -f schema.sql
```

তারপর:
```bash
npm run dev
```
`http://localhost:3000/api/health` এ `{"ok":true}` এলে API চালু।

## 3. প্রথম Admin তৈরি
`ADMIN_EMAIL` ও `ADMIN_PASSWORD`-এর ঠিক একই মান দিয়ে POST করুন:
```bash
curl -X POST http://localhost:3000/api/setup/admin \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@example.com","password":"replace-this-before-deploying"}'
```
Response-এর `token` নিরাপদে রাখুন। প্রথম admin তৈরির পর `/api/setup/admin` endpoint কোড থেকে মুছে ফেলুন/বন্ধ করুন এবং সার্ভার redeploy করুন। বাস্তব পাসওয়ার্ড বা token কারও সঙ্গে শেয়ার করবেন না।

## 4. Service যোগ করা
Admin token দিয়ে POST করুন:
```bash
curl -X POST http://localhost:3000/api/admin/services \
  -H "Authorization: Bearer YOUR_ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name":"Social profile audit",
    "platform":"Instagram",
    "category":"Analytics",
    "description":"Authorized account analytics report",
    "price_per_1000_cents":250,
    "min_quantity":1,
    "max_quantity":100,
    "provider_service_id":null
  }'
```
`price_per_1000_cents` হলো প্রতি 1,000 ইউনিটের মূল্য **সেন্টে**। যেমন 250 = $2.50। নিজের মুদ্রা/পেমেন্ট প্রোভাইডারের জন্য currency model ঠিক করে নিন; starter UI-তে USD দেখানো হয়।

## 5. API endpoint
- `GET /api/health` — health check
- `POST /api/auth/login` — email/password login
- `GET /api/me` — signed-in user
- `GET /api/services` — active service list
- `GET /api/dashboard` — user balance/order summary
- `POST /api/orders` — order create; balance থেকে amount reserve/deduct
- `GET /api/orders` — user's order history
- `GET /api/admin/summary` — admin summary
- `GET /api/admin/users` — users
- `POST /api/admin/services` — create service
- `PATCH /api/admin/services/:id` — activate/deactivate service
- `GET /api/admin/orders` — all orders
- `PATCH /api/admin/orders/:id/status` — update status; cancel হলে balance refund
- `POST /api/payments/webhook` — placeholder; intentionally not enabled
- `POST /api/admin/provider/submit-order` — placeholder; provider contract না বসানো পর্যন্ত কাজ করবে না

## 6. Telegram Bot
`.env`-এ বসান:
```env
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_BOT_USERNAME=your_bot_username
MINI_APP_URL=https://your-deployed-site.example
```
তারপর server restart করুন। `/start`-এ Mini App খোলার button থাকবে। Bot token গোপন রাখবেন।

## 7. Telegram Mini App নিরাপত্তা
বর্তমান frontend Telegram-এর মধ্যে খুলতে পারে, কিন্তু Telegram identity-কে server-side-এ যাচাই করে user account-এ bind করার অংশ starter-এ সম্পূর্ণ করা হয়নি। Production-এ Telegram `initData` raw string backend-এ পাঠিয়ে Telegram-এর documented HMAC validation ও freshness check করুন; client থেকে পাঠানো `user.id` একা বিশ্বাস করবেন না। এরপর verified Telegram ID দিয়ে user তৈরি/লিংক করবেন।

## 8. Payment integration
প্রতিটি provider-এর জন্য আলাদা implementation লাগে। Flow:
1. Server-এ deposit intent তৈরি করুন।
2. Payment provider checkout/session তৈরি করুন।
3. Provider-এর webhook signature server-side যাচাই করুন।
4. Unique provider transaction reference দিয়ে duplicate webhook আটকান।
5. Database transaction-এর মধ্যে payment `Verified` করুন এবং একবারই balance যোগ করুন।
6. Failed/expired payment balance-এ টাকা যোগ করবে না।
Webhook endpoint এখন 501 দেয়—provider-specific signature verification না লেখা পর্যন্ত সেটি এভাবেই রাখুন।

## 9. Provider API integration
Provider-এর official API docs থেকে authentication, create-order, order-status, cancel/refill support এবং rate limits যাচাই করুন। Server-side API key ব্যবহার করুন। Response validation, timeout, retries with idempotency, provider-order mapping ও audit logs যোগ করুন। অজানা API format অনুমান করে production order পাঠাবেন না।

## 10. Production checklist
- Admin bootstrap route সরান
- Strong secrets; secrets repo-তে commit করবেন না
- HTTPS, rate limits, input validation, admin audit trail
- Telegram Mini App initData server-side validation
- Payment webhook signature verification + idempotency
- Provider API timeout/retry/idempotency
- Database backup/restore test
- Privacy policy, refund policy, support contact
- Only platform-compliant services; no password collection
