import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { Pool } from 'pg';
import { Telegraf } from 'telegraf';

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false } });
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET;

if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error('Set JWT_SECRET to a random secret of at least 32 characters.');
  process.exit(1);
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '100kb' }));
app.use(express.static('public'));

function signToken(user) {
  return jwt.sign({ sub: String(user.id), role: user.role }, JWT_SECRET, { expiresIn: '7d' });
}
function auth(req, res, next) {
  try {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const payload = jwt.verify(token, JWT_SECRET);
    req.auth = { id: Number(payload.sub), role: payload.role };
    next();
  } catch {
    res.status(401).json({ error: 'Please sign in.' });
  }
}
function adminOnly(req, res, next) {
  if (req.auth?.role !== 'admin') return res.status(403).json({ error: 'Admin access required.' });
  next();
}
function validTargetUrl(value) {
  try {
    const u = new URL(value);
    return ['http:', 'https:'].includes(u.protocol);
  } catch { return false; }
}
function centsFor(quantity, pricePer1000) {
  return Math.ceil((Number(quantity) * Number(pricePer1000)) / 1000);
}

app.get('/api/health', (_req, res) => res.json({ ok: true }));

// One-time admin bootstrap. Configure ADMIN_EMAIL and ADMIN_PASSWORD, then call once.
// In production, remove/disable this endpoint after creating the admin.
app.post('/api/setup/admin', async (req, res) => {
  const { email, password } = req.body || {};
  if (!process.env.ADMIN_EMAIL || !process.env.ADMIN_PASSWORD ||
      email !== process.env.ADMIN_EMAIL || password !== process.env.ADMIN_PASSWORD) {
    return res.status(403).json({ error: 'Bootstrap credentials did not match environment settings.' });
  }
  const count = await pool.query("SELECT COUNT(*)::int AS n FROM users WHERE role='admin'");
  if (count.rows[0].n > 0) return res.status(409).json({ error: 'Admin already exists. Disable this endpoint after setup.' });
  const hash = await bcrypt.hash(password, 12);
  const result = await pool.query(
    'INSERT INTO users(email,password_hash,role) VALUES($1,$2,$3) RETURNING id,email,role,balance_cents',
    [email, hash, 'admin']
  );
  res.json({ token: signToken(result.rows[0]), user: result.rows[0] });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });
  const result = await pool.query('SELECT * FROM users WHERE email=$1', [String(email).toLowerCase()]);
  const user = result.rows[0];
  if (!user?.password_hash || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }
  res.json({ token: signToken(user), user: { id: user.id, email: user.email, role: user.role, balance_cents: user.balance_cents } });
});

app.get('/api/me', auth, async (req, res) => {
  const r = await pool.query('SELECT id,email,telegram_id,role,balance_cents,created_at FROM users WHERE id=$1', [req.auth.id]);
  if (!r.rowCount) return res.status(404).json({ error: 'User not found.' });
  res.json(r.rows[0]);
});

app.get('/api/services', async (_req, res) => {
  const r = await pool.query(
    'SELECT id,name,platform,category,description,price_per_1000_cents,min_quantity,max_quantity FROM services WHERE active=TRUE ORDER BY platform,category,name'
  );
  res.json(r.rows);
});

app.get('/api/dashboard', auth, async (req, res) => {
  const [user, counts, recent] = await Promise.all([
    pool.query('SELECT balance_cents FROM users WHERE id=$1', [req.auth.id]),
    pool.query("SELECT status,COUNT(*)::int AS count FROM orders WHERE user_id=$1 GROUP BY status", [req.auth.id]),
    pool.query(`SELECT o.id,o.target_url,o.quantity,o.amount_cents,o.status,o.created_at,s.name AS service_name
      FROM orders o JOIN services s ON s.id=o.service_id WHERE o.user_id=$1 ORDER BY o.created_at DESC LIMIT 5`, [req.auth.id])
  ]);
  res.json({
    balance_cents: user.rows[0]?.balance_cents ?? 0,
    order_counts: Object.fromEntries(counts.rows.map(x => [x.status, x.count])),
    recent_orders: recent.rows
  });
});

app.post('/api/orders', auth, async (req, res) => {
  const { service_id, target_url, quantity } = req.body || {};
  const qty = Number(quantity);
  if (!validTargetUrl(target_url)) return res.status(400).json({ error: 'Enter a valid http/https target URL.' });
  if (!Number.isSafeInteger(qty) || qty < 1) return res.status(400).json({ error: 'Quantity must be a positive whole number.' });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const sr = await client.query('SELECT * FROM services WHERE id=$1 AND active=TRUE FOR SHARE', [service_id]);
    const service = sr.rows[0];
    if (!service) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Service not found or inactive.' }); }
    if (qty < service.min_quantity || qty > service.max_quantity) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: `Quantity must be ${service.min_quantity}–${service.max_quantity}.` });
    }
    const amount = centsFor(qty, service.price_per_1000_cents);
    const ur = await client.query('SELECT balance_cents FROM users WHERE id=$1 FOR UPDATE', [req.auth.id]);
    if (!ur.rows[0] || Number(ur.rows[0].balance_cents) < amount) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Insufficient balance. Add funds first.' });
    }
    await client.query('UPDATE users SET balance_cents=balance_cents-$1 WHERE id=$2', [amount, req.auth.id]);
    const order = await client.query(
      `INSERT INTO orders(user_id,service_id,target_url,quantity,amount_cents,status)
       VALUES($1,$2,$3,$4,$5,'Pending')
       RETURNING id,service_id,target_url,quantity,amount_cents,status,created_at`,
      [req.auth.id, service.id, target_url, qty, amount]
    );
    await client.query('COMMIT');
    res.status(201).json({ ...order.rows[0], service_name: service.name, message: 'Order created. It is pending review.' });
  } catch (e) {
    await client.query('ROLLBACK');
    console.error(e);
    res.status(500).json({ error: 'Could not create order.' });
  } finally { client.release(); }
});

app.get('/api/orders', auth, async (req, res) => {
  const r = await pool.query(`SELECT o.id,o.target_url,o.quantity,o.amount_cents,o.status,o.created_at,o.updated_at,s.name AS service_name
    FROM orders o JOIN services s ON s.id=o.service_id WHERE o.user_id=$1 ORDER BY o.created_at DESC LIMIT 100`, [req.auth.id]);
  res.json(r.rows);
});

// Admin: summary, service management, user list, order status.
app.get('/api/admin/summary', auth, adminOnly, async (_req, res) => {
  const [users, orders, pending, revenue, services] = await Promise.all([
    pool.query('SELECT COUNT(*)::int AS n FROM users'),
    pool.query('SELECT COUNT(*)::int AS n FROM orders'),
    pool.query("SELECT COUNT(*)::int AS n FROM orders WHERE status='Pending'"),
    pool.query("SELECT COALESCE(SUM(amount_cents),0)::bigint AS cents FROM orders WHERE status <> 'Cancelled'"),
    pool.query('SELECT COUNT(*)::int AS n FROM services')
  ]);
  res.json({ users: users.rows[0].n, orders: orders.rows[0].n, pending_orders: pending.rows[0].n, order_value_cents: revenue.rows[0].cents, services: services.rows[0].n });
});

app.get('/api/admin/users', auth, adminOnly, async (_req, res) => {
  const r = await pool.query('SELECT id,email,telegram_id,role,balance_cents,created_at FROM users ORDER BY created_at DESC LIMIT 200');
  res.json(r.rows);
});

app.post('/api/admin/services', auth, adminOnly, async (req, res) => {
  const { name, platform, category, description = '', price_per_1000_cents, min_quantity = 10, max_quantity = 10000, provider_service_id = null } = req.body || {};
  if (!name || !platform || !category || !Number.isSafeInteger(Number(price_per_1000_cents)) ||
      Number(price_per_1000_cents) < 0 || !Number.isInteger(Number(min_quantity)) ||
      !Number.isInteger(Number(max_quantity)) || Number(min_quantity) < 1 || Number(max_quantity) < Number(min_quantity)) {
    return res.status(400).json({ error: 'Invalid service fields.' });
  }
  const r = await pool.query(`INSERT INTO services(name,platform,category,description,price_per_1000_cents,min_quantity,max_quantity,provider_service_id)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [name, platform, category, description, Number(price_per_1000_cents), Number(min_quantity), Number(max_quantity), provider_service_id]);
  res.status(201).json(r.rows[0]);
});

app.patch('/api/admin/services/:id', auth, adminOnly, async (req, res) => {
  const { active } = req.body || {};
  if (typeof active !== 'boolean') return res.status(400).json({ error: 'Send active: true or false.' });
  const r = await pool.query('UPDATE services SET active=$1 WHERE id=$2 RETURNING *', [active, req.params.id]);
  if (!r.rowCount) return res.status(404).json({ error: 'Service not found.' });
  res.json(r.rows[0]);
});

app.get('/api/admin/orders', auth, adminOnly, async (_req, res) => {
  const r = await pool.query(`SELECT o.*,u.email,u.telegram_id,s.name AS service_name FROM orders o
    JOIN users u ON u.id=o.user_id JOIN services s ON s.id=o.service_id ORDER BY o.created_at DESC LIMIT 300`);
  res.json(r.rows);
});

app.patch('/api/admin/orders/:id/status', auth, adminOnly, async (req, res) => {
  const allowed = ['Pending','Processing','Completed','Cancelled'];
  const { status } = req.body || {};
  if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status.' });
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const r = await client.query('SELECT * FROM orders WHERE id=$1 FOR UPDATE', [req.params.id]);
    const order = r.rows[0];
    if (!order) { await client.query('ROLLBACK'); return res.status(404).json({ error: 'Order not found.' }); }
    if (order.status !== 'Cancelled' && status === 'Cancelled') {
      await client.query('UPDATE users SET balance_cents=balance_cents+$1 WHERE id=$2', [order.amount_cents, order.user_id]);
    } else if (order.status === 'Cancelled' && status !== 'Cancelled') {
      const u = await client.query('SELECT balance_cents FROM users WHERE id=$1 FOR UPDATE', [order.user_id]);
      if (Number(u.rows[0].balance_cents) < Number(order.amount_cents)) {
        await client.query('ROLLBACK'); return res.status(400).json({ error: 'User balance is insufficient to reactivate this order.' });
      }
      await client.query('UPDATE users SET balance_cents=balance_cents-$1 WHERE id=$2', [order.amount_cents, order.user_id]);
    }
    const updated = await client.query('UPDATE orders SET status=$1,updated_at=NOW() WHERE id=$2 RETURNING *', [status, order.id]);
    await client.query('COMMIT');
    res.json(updated.rows[0]);
  } catch (e) {
    await client.query('ROLLBACK'); console.error(e); res.status(500).json({ error: 'Could not update order.' });
  } finally { client.release(); }
});

// Payment webhook pattern: verify signatures with your payment provider's official SDK before crediting.
// This endpoint intentionally does not accept client-asserted "paid" status.
app.post('/api/payments/webhook', async (_req, res) => {
  res.status(501).json({ error: 'Payment webhook not configured. Add provider-specific signature verification before enabling deposits.' });
});

// Provider API integration intentionally fails closed until a real provider's API contract is configured.
// Never expose provider API keys to browser / Mini App code.
app.post('/api/admin/provider/submit-order', auth, adminOnly, async (req, res) => {
  if (!process.env.SMM_PROVIDER_BASE_URL || !process.env.SMM_PROVIDER_API_KEY) {
    return res.status(503).json({ error: 'Provider API is not configured.' });
  }
  res.status(501).json({ error: 'Implement the provider-specific request format and response validation before enabling this route.' });
});

let bot;
if (process.env.TELEGRAM_BOT_TOKEN) {
  bot = new Telegraf(process.env.TELEGRAM_BOT_TOKEN);
  bot.start(async (ctx) => {
    const miniUrl = process.env.MINI_APP_URL;
    await ctx.reply('Welcome to the SMM Panel. Open the app to browse services and manage your orders.', {
      reply_markup: {
        inline_keyboard: [[{ text: 'Open SMM Panel', web_app: { url: miniUrl } }], [{ text: 'My orders', callback_data: 'my_orders' }]]
      }
    });
  });
  bot.action('my_orders', async (ctx) => {
    await ctx.answerCbQuery();
    const tgId = String(ctx.from.id);
    const u = await pool.query('SELECT id FROM users WHERE telegram_id=$1', [tgId]);
    if (!u.rowCount) return ctx.reply('Your Telegram account is not linked yet. Open the Mini App to link your account.');
    const orders = await pool.query(`SELECT o.id,o.status,s.name FROM orders o JOIN services s ON s.id=o.service_id
      WHERE o.user_id=$1 ORDER BY o.created_at DESC LIMIT 10`, [u.rows[0].id]);
    if (!orders.rowCount) return ctx.reply('No orders yet.');
    await ctx.reply(orders.rows.map(o => `#${o.id} — ${o.name} — ${o.status}`).join('\n'));
  });
  bot.launch().catch(err => console.error('Telegram bot failed to start:', err));
  process.once('SIGINT', () => bot?.stop('SIGINT'));
  process.once('SIGTERM', () => bot?.stop('SIGTERM'));
}

app.listen(PORT, () => console.log(`SMM panel starter listening on port ${PORT}`));
